import { Component,useState } from 'react'
import reactLogo from './assets/react.svg'
import viteLogo from '/vite.svg'
import './App.css'
import Counter from './Counter'
import Count from './UseReducer'
import WithUseMemo from './Memo'
import Parent from './Callback'
import CounterApp from './CounterApp'
function App() {
  const [count, setCount] = useState(0)

  return (
    <>
      {/*<Ref/>
      <AccessingDom/><br/>
      <Track/>
      <BatteryHook/>
      <Count/>
      <Counter/>
      <WithUseMemo/>
      <Parent/>*/}
      <CounterApp/>
   </>
  )
}

export default App
