import React, { useState, useCallback} from "react";
function Child({onClick}){
    console.log("Child component re-rendered");
    return <button onClick={onClick}>Click Me</button>;
}
function Parent(){
    const [count,setCount]=useState(0);
     //usecallback keeps the same function unless dependencies change 
    const handleClick=useCallback(()=>{
        console.log("Button clicked!");
    },[]);
    return(
        <div>
            <h3>Count:{count}</h3>
            <button onClick={()=>setCount(count +1)}>Increment Count</button>
            <Child onClick={handleClick}/>
        </div>
    );
}
export default Parent;
