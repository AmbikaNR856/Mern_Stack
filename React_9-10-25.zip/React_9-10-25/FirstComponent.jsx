import React from 'react'

function FirstComponent(Tejaswini) {
  return (
    <div>
      <h1>FirstComponent {Tejaswini.name}</h1>
      <SecondComponent phno="8088103533"/>

    </div>
  )
}
function SecondComponent(Tejaswini1) {
  return (
    <div>
      SecondComponent {Tejaswini1.phno}

    </div>
  )
}

export default FirstComponent
