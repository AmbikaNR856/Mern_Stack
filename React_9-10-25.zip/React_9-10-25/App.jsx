import React from 'react'
import FirstComponent from './FirstComponent'
import Fruit from './ClassOne'
import Parent from './PropsChildren'
function App() {
  return (
    <div>
      <FirstComponent name="Ambika"/>
      <FirstComponent name="Tejaswini"/>
      <FirstComponent name="Faiza"/>
      <Fruit/>
      <Parent/>
    </div>
  )
}

export default App
