import { Component,useState } from 'react'
import reactLogo from './assets/react.svg'
import viteLogo from '/vite.svg'
import './App.css'
import Component1 from './ContextAPI'
import Ref from './Ref'
import AccessingDom from './AccessingDom'
import Track from './Track'
import BatteryHook from './BatteryHook'

function App() {
  const [count, setCount] = useState(0)

  return (
    <>
      <Ref/>
      <AccessingDom/><br/>
      <Track/>
      <BatteryHook/>
      
    </>
  )
}

export default App
