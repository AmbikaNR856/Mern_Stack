import React from 'react'
import {Link} from 'react-router-dom'
function index() {
  return (
    <div>
      <h1>This is index page</h1>
      <nav>
        <Link to='/home'>HomePage ||</Link>
        <Link to='/about'>AboutUs || </Link>
        <Link to='/contact'>ContactUs</Link>
      </nav>
    </div>
  )
}

export default index
