import React from 'react'

import { BrowserRouter,Routes,Route } from 'react-router-dom'
import About from './About'
import Contact from './Contact'
import Home from './Home'
import Index1 from './Index'

function App() {
  return (
    <div>
 
    <BrowserRouter>
    <Routes>
      <Route path='/' element={<Index1/>}/>
      <Route path='home/' element={<Home/>}/>
      <Route path='about/' element={<About/>}/>
      <Route path='contact/' element={<Contact/>}/>
    </Routes>
    </BrowserRouter>
    </div>
  )
}

export default App