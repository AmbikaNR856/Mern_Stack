import "./ExternalCss.css";
function External(){
    return <h5 className="title">React External CSS</h5>
}
export default External;