import React,{useEffect,use, useState} from 'react'

function Userslist() {
    const [users,setUsers]=useState([]);
    const [loading,setLoading]=useState(true);
    useEffect(()=>{
        async function fetchData(){
            const res=await
            fetch("https://jsonplaceholder.typicode.com/users");
            const data=await res.json();
            setUsers(data);
            setLoading(false);
        }
        fetchData();
    },[]);
  return (
    <div>
      <h2>Users List</h2>{loading? (
        <p>Loading...</p>
      ):(
        <ul>
            <h2>Names</h2>
            {users.map((user)=>(
                <div><li key={user.id}>{user.name}</li>
                <img src={user.image}/></div>
            ))}<br></br>
            <h2>Email</h2>
            {users.map((user)=>(
                <li key={user.id}>{user.email}</li>
            ))}<br></br>
            <h2>Address</h2>
            {users.map((user)=>(
                <li key={user.id}>{user.address.street}</li>
            ))}
            
        </ul>
      )}
    </div>
  );
}

export default Userslist;
