import React from 'react'
import Pass from './Conditionalrendering'
import Check from './Conditionalrendering'
import Car1 from './DestructuringOne'
import Car2 from './Destructuring2'
import Parent1 from './Propdrilling'
function App() {
  return (
    <div>
      <Check isresult={false}/>
      <Check isresult={true}/>
      <Car1 color='black'/>
      <Car2 />
      <Parent1 studentName='Ambika'/>
    </div>
  )
}

export default App
