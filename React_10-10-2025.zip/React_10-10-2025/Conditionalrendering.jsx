import React from 'react'
import { createRoot } from 'react-dom/client';

function Pass() {
  return (
  <h1>Congratulations!</h1>
  );
}
function Fail(){
    return (
    <h1>Better Luck Next Time!</h1>
    );
}
{/*function Check(props){
    const isresult=props.isresult;
    console.log(isresult);
    if(isresult === "True"){
        return <Pass/>;
    }
    if(isresult === "Fail"){
    return <Fail/>;
    }
}*/}
function ClassResult(props){
    const isresult=props.isresult;
    return(
        <>
        {isresult?<Pass/>:<Fail/>}
        </>
    );
}


export default ClassResult
