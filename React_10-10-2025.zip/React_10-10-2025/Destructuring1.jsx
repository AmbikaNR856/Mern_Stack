import React from 'react'

function Car1({color}) {
  return (
    <div>
      <h2>My car is {color}!</h2>
    </div>
  );
}

export default Car1;
