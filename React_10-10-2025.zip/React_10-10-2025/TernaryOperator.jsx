import React from 'react'

function ClassResult(props) {
  return (
    <div>
      
    </div>
  )
}

export default ClassResult
props