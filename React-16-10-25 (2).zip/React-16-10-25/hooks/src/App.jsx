import { useState } from 'react'
import reactLogo from './assets/react.svg'
import viteLogo from '/vite.svg'
import Example from './hooks'
import Counter from './Counter'
import Cleanup from './Cleanup'
import Userslist from './Userslist'
import Greeting from './Css'
import External from './External'
import Button from './Button'
import Productcard from './StyledComponents'

function App() {
  const [count, setCount] = useState(0)

  return (
    <>
      {/*<Example/>
      <Counter/>
      <Cleanup/>
      <Userslist/>
      <Greeting/>*/}
      <External/>
      <Button/>
      <Productcard/>
    </>
  )
}

export default App
