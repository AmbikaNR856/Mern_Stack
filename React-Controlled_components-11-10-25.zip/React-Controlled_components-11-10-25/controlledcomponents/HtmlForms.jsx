import React from 'react'

function HtmlForms() {
  return (
    <div>
      <form>
        <input type='email'id='user'/><br/>
          <input type='password'id='user'/>
        <button>Submit</button>
      </form>
      <p>
        
      </p>
    </div>
  )
}
export default HtmlForms
