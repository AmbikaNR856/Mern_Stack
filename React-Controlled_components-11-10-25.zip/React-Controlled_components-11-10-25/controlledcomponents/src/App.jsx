import React from 'react'
import HtmlForms from '../HtmlForms'
import ControlledForm from '../ControlledForm'
import TwoWayBinding from '../TwoWayBinding'
import FormValidation from '../FormValidation'

function App() {
  return (
    <div>
      {/*<HtmlForms/>
      <ControlledForm/>
      <TwoWayBinding/>*/}
      <FormValidation/>
    </div>
  )
}

export default App
