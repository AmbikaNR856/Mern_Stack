import React, { useState } from 'react'

function FormValidation() {
    const[email,setEmail]=useState("");
    const[error,setError]=useState("");
    const[num,setNumber]=useState("");
    const[error2,setError2]=useState("");
    const handleSubmit=(e) =>{
        e.preventDefault();
        if(!email.includes("@")){
            setError("Please enter a valid email!");
        }else{
            setError("");
            alert(`Email Submitted: ${email}`);
        }
        if(num.length>10 && num.length< 10){
            setError2("Enter the 10 digit numbers");
        }else{
            setError2("");
            alert(` valid number:${num}`)
        }
    };
  return (
    <form onSubmit={handleSubmit}>

        <input type="email"value={email} onChange={(e)=>setEmail(e.target.value)} /><br/>
    
       <input type="num"value={num} onChange={(e)=>setNumber(e.target.value)} /><br/>      
     <button type='submit'>Submit</button>
        {error && <p style={{ color: "red"}}>{error}</p>}
        {error2&& <p style={{ color: "red"}}>{error2}</p>}
    </form>
  );
}

export default FormValidation